angular.module('mainApp.reporteLiqF', [])
    .controller('reporteLiqFCtrl', function ($scope) {
        $scope.message = "Reporte de Planillas de Liquidacion por fecha";
    });
