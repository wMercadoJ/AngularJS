angular.module('mainApp.reporteSalProdE', [])
    .controller('reporteSalProdECtrl', function ($scope) {
        $scope.message = "Reporte de Planillas de Salida por Empleado";
    });
