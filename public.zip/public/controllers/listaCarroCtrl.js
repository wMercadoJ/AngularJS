angular.module('mainApp.listaCarro', [])
    .controller('listaCarroCtrl', function ($scope) {
        $scope.message = "Lista de Carros";
    });