angular.module('mainApp.nuevoEmpleado', [])
    .controller('nuevoEmpleadoCtrl', function ($scope) {
        $scope.message = "Crear nuevo empleado:";
    });
