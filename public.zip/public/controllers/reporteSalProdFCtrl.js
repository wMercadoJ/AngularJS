angular.module('mainApp.reporteSalProdF', [])
    .controller('reporteSalProdFCtrl', function ($scope) {
        $scope.message = "Reporte de Planillas de Salida por fecha";
    });
