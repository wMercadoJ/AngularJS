angular.module('mainApp.listaUser', [])
    .controller('listaUserCtrl', function ($scope) {
        $scope.message = "Usuarios existentes en Sistema";
    });