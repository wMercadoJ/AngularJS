angular.module('mainApp.planillaLiq', [])
    .controller('planillaLiqCtrl', function ($scope) {
        $scope.message = "Planilla de Liquidacion del dia";
    });
