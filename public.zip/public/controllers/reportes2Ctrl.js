angular.module('mainApp.reportes2', [])
    .controller('reportes2Ctrl', function ($scope) {
        $scope.message = "Reportes 2";
    });