angular.module('mainApp.reportes1', [])
    .controller('reportes1Ctrl', function ($scope) {
        $scope.message = "Reportes 1";
    });