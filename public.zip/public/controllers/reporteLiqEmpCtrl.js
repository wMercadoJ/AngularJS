angular.module('mainApp.reporteLiqEmp', [])
    .controller('reporteLiqEmpCtrl', function ($scope) {
        $scope.message = "Reporte de Planillas de Liquidacion por Empleado";
    });
