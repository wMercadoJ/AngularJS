angular.module('mainApp.reporteProductoExistAl', [])
    .controller('reporteProductoExistAlCtrl', function ($scope) {
        $scope.message = "Reporte Productos fisicos existentes en alamcenes";
    });