angular.module('mainApp.reporteProductoGral', [])
    .controller('reporteProductoGralCtrl', function ($scope) {
        $scope.message = "Reporte Productos en gral";
    });