angular.module('mainApp.reportes', [])
    .controller('reportesCtrl', function ($scope) {
        $scope.message = "Reportes";
    });