angular.module('mainApp.planillaDiaAlCAl', [])
    .controller('planillaDiaAlCAlCtrl', function ($scope) {
        $scope.message = "Lista de Planilla de Salidas Almacenes del dia";
    });