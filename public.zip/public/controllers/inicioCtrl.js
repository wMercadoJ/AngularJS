angular.module('mainApp.inicio', [])
    .controller('inicioCtrl', function ($scope) {
        $scope.message = "Bienvenido al Sistema de Salidas de Productos";
    });
