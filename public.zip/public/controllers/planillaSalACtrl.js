angular.module('mainApp.planillaSalA', [])
    .controller('planillaSalACtrl', function ($scope) {
        $scope.message = "Planillas Revisadas del dia:";
    });