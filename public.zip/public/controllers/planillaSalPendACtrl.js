angular.module('mainApp.planillaSalPendA', [])
    .controller('planillaSalPendACtrl', function ($scope) {
        $scope.message = "Planillas Pendientes del dia:";
    });