angular.module('mainApp.registroProductos', [])
    .controller('registroProductosCtrl', function ($scope) {
        $scope.message = "Registro de Productos";
    });
