angular.module('mainApp.planillaLiqPend', [])
    .controller('planillaLiqPendCtrl', function ($scope) {
        $scope.message = "Planillas de Liquidacion Pendientes:";
    });