angular.module('mainApp.listaEmpAd', [])
    .controller('listaEmpAdCtrl', function ($scope) {
        $scope.message = "Lista de Empleados";
    });