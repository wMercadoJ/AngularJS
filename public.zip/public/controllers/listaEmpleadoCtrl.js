angular.module('mainApp.listaEmpleado', [])
    .controller('listaEmpleadoCtrl', function ($scope) {
        $scope.message = "Empleados existentes en Sistema";
    });