angular.module('mainApp.nuevoUser', [])
    .controller('nuevoUserCtrl', function ($scope) {
        $scope.message = "Crear nuevo Usuario:";
    });