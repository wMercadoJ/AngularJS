angular.module('mainApp.nuevaPlanillaAl', [])
    .controller('nuevaPlanillaAlCtrl', ['$scope', function($scope) {
        $scope.message = "Crear Nueva Planilla";
        $scope.date = new Date();
        $scope.carros = ['ABC123 - Chofer1', 'BCD123 - Chofer2', 'EFG123 - Chofer3'];
        //  $scope.selection = $scope.carros[0];
    }]);